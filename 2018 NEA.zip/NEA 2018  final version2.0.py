import csv
global score
score = 0

bio_questions = [['1.Name the organelles where protiens are synthesised? A.Ribosome or B.Mitchodria: ','2.What enzyme breaks down carbohydrases? A.Lipids or B.Carbohydrases: ','3.What is meant by the definition of comunicable disease? A.The disease can talk or B.A disease that can be transmitted from person to person: ','4.Define photosynthesis? A.the process where plants sunlight to synthesize nutrients from carbon dioxide and water or B.Where plants take pictures: ','5.What part of your body never stops growing? A.Ears or B.Hands: '],
                 ['1.Name the organelles where protiens are synthesised? A.Ribosome or B.Mitchodria or C.Nucleaus: ','2.What enzyme breaks down carbohydrases? A.Lipids or B.Carbohydrases or C.Protease: ','3.What is meant by the definition of comunicable disease? A.The disease can talk or B.A disease that can be transmitted from person to person or C.A disease that can\'t be transmitted from person to person: ','4.Define photosynthesis? A.the process where plants sunlight to synthesize nutrients from carbon dioxide and water or B.Where plants take pictures or C.Where plants use sunlight and oxygen to synthesize nutrients?: ','5.What part of your body never stops growing? A.Ears or B.Hands or C.Feet: '],
                 ['1.Name the organelles where protiens are synthesised? A.Ribosome or B.Mitchodria or C.Nucleaus or D.Vacuole: ','2.What enzyme breaks down carbohydrases? A.Lipids or B.Carbohydrases or C.Protease or D.Amylase: ','3.What is meant by the definition of comunicable disease? A.The disease can talk or B.A disease that can be transmitted from person to person or C.A disease that can\'t be transmitted from person to person or D.A communist disease: ','4.Define photosynthesis? A.the process where plants sunlight to synthesize nutrients from carbon dioxide and water or B.Where plants take pictures or C.Where plants use sunlight and oxygen to synthesize nutrients or D.Where plants user CO2 and glucose to produce Oxygen: ','5.What part of your body never stops growing? A.Ears or B.Hands or C.Feet D.Body: ']]

phy_questions = [['1.What is largest planet in our solar system? A.Jupiter or B.Saturn: ','2.Which of the following planets does not have rings? A.Mars or B.Saturn: ','3.How long does it take the Earth to complete a full orbit around the Sun? A.2 years or B.1 year: ','4.Whats the biggest star in our solar system? A.The sun or B.The moon: ','5.What is the hottest planet in our solar system? A.Mercury or B.Venus: '],
                 ['1.What is largest planet in our solar system? A.Jupiter or B.Saturn or C.Neptune: ','2.Which of the following planets does not have rings? A.Mars or B.Saturn or C.Juipter: ','3.How long does it take the Earth to complete a full orbit around the Sun? A.2 years or B.1 year or C.10 years: ','4.Whats the biggest star in our solar system? A.The sun or B.The moon or C.The Earth: ','5.What is the hottest planet in our solar system? A.Mercury or B.Venus or C.Mars: '],
                 ['1.What is largest planet in our solar system? A.Jupiter or B.Saturn or C.Neptune or D.Uranus: ','2.Which of the following planets does not have rings? A.Mars or B.Saturn or C.Jupiter or D.Uranus: ','3.How long does it take the Earth to complete a full orbit around the Sun? A.2 years or B.1 year or C.10 years or D.100 years: ','4.Whats the biggest star in our solar system? A.The sun or B.The moon or C.The Earth or D.None of these: ','5.What is the hottest planet in our solar system? A.Mercury or B.Venus or C.Mars or D.Pluto: ']]

cs_questions = [['1.Hexadecimal means? A.Base 16 or B.Base 8: ','2.How many bits are in a byte? A.6 or B.8: ','3.How many MB in a Gigga byte A.1024MB or B.2028MB: ','4.Define open source software A.It\'s an open bottle of ketchup or B.It\'s a free program: ','5.Which of these is an example of secondry? A.SSD or B.Cache: '],
                ['1.Hexadecimal means? A.Base 16 or B.Base 8 or C.base 10: ','2.How many bits are in a byte? A.6 or B.8 or C.16: ','3.How many MB in a Gigga byte A.1024MB or B.2028MB or C.1024kb: ','4.Define open source software A.It\'s an open bottle of ketchup or B.It\'s a free program OR C.It\'s a paid subscription: ','5.Which of these is an example of secondry? A.SSD or B.Cache or C.RAM: '],
                ['1.Hexadecimal means? A.Base 16 or B.Base 8 or C.base 10 or D.Base 2: ','2.How many bits are in a byte? A.6 or B.8 or C.16 or D.4: ','3.How many MB in a Gigga byte A.1024MB or B.2028MB or C.1024kb or D.3072: ','4.Define open source software A.It\'s an open bottle of ketchup or B.It\'s a free program OR C.It\'s a paid subscription or D.None of these: ','5.Which of these is an example of secondry? A.SSD or B.Cache or C.RAM or D.ROM: ']]

bio_answers = ['A','B','B','A','A']
phy_answers = ['A','A','B','A','A']
cs_answers = ['A','B','A','B','A']

print ('_________________________')
print ('#########################')
print ('##########QUIZ###########')
print ('#########################')
print ('_________________________')


def main():
    while True:
        user = input ('Are you a student or a teacher?: ')
        if user == 'student':
            while True:
                user_input = input ('Hello would you like to A.Register or B.Login?: ')
                if user_input == 'A':
                    register()
                    
                elif user_input == 'B':
                    login()
                    
                else:
                    print ('Sorry that\'s not a valid input try again')
                    
        elif user == 'teacher':
            teacher()
            
        else:
            print ('Sorry that\'s not a valid input please try again')

def user_name(name, age):
    global username
    username = name[0:3]+age

def Pass():
    global password
    password = input("Please enter your password: ")
    

def register():
    file = open ('NEA usernames.csv','a+')
    name = input ('Good afternoon please enter your name: ')
    surname = input ('Please enter your surname: ')
    age = input('Please enter your age: ')
    year_group = input ('Please enter your year group: ')
    form = input ('What form are you in?: ')
    user_name(name, age)
    print (username)
    Pass()
    new_data = name+','+surname+','+age+','+year_group+','+form+','+username+','+password
    file.write ("\n")
    file.write(str(new_data ))
    file.write("\n")
    file.close()
            
def login():
    myfile = open('NEA usernames.csv','r')
    username = input ('Please enter your user name: ')
    for row in myfile:
        if username in row:
            password = input ('Please enter your password: ')
            if password in row:
                print ('Hello '+ username)
                myfile.close
                print ('There are 10 questions on 3 topics and 3 difficulties. Easy 2 possible answers Medium 3 possible answers Hard 4 Possible answers')
                print ('Please enter it as A and B or A and C ect...')
                topic()
                if c_topic == 'A and B':
                    bio_phy(username, score)
                elif c_topic == 'A and C':
                    bio_cs(username, score)
                elif c_topic == 'B and C':
                    phy_cs(username, score)
            else:
              print("Inncorect password")
        
def topic():
  global c_topic
  c_topic = input ('What two topics would you like to be tested on A.Biology B.Physics C.Computer science?: ')
  
def bio_phy(username, score):
    i = 0
    x = 0
    q1 = 0
    a1 = 0
    q2 = 0
    a2 = 0
    myfile = open('NEA usernames.csv','r')
    difficulty = input('What difficulty would you like to play on?. Easy 2 possible answers Medium 3 possible answers Hard 4 Possible answers: ')
    if difficulty == 'Easy':
        print ('Biology questions first')
        for i in range (0,5):
            question = input(bio_questions[0][q1]).upper()
            if question == (bio_answers[a1]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')

            q1+=1
            a1+=1
     
        for x in range (0,5):
            question = input(phy_questions[0][q2]).upper()
            if question == (phy_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Bio & Phy")
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
            
    elif difficulty == 'Medium':
        print ('Biology questions first')
        for i in range (0,5):
            question = input(bio_questions[1][q1]).upper()
            if question == (bio_answers[a1]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')

            q1+=1
            a1+=1
     
        for x in range (0,5):
            question = input(phy_questions[1][q2]).upper()
            if question == (phy_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Bio & Phy")
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
             
    elif difficulty == 'Hard':
        print ('Biology questions first')
        for i in range (0,5):
            question = input(bio_questions[2][q1]).upper()
            if question == (bio_answers[a1]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')

            q1+=1
            a1+=1
     
        for x in range (0,5):
            question = input(phy_questions[2][q2]).upper()
            if question == (phy_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Bio & Phy")
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
            
    else:
        print ('Invalid response please try again')
            
def bio_cs(username, score):
    i = 0
    x = 0
    q1 = 0
    a1 = 0
    q2 = 0
    a2 = 0
    myfile = open('NEA usernames.csv','r')
    difficulty = input('What difficulty would you like to play on?. Easy 2 possible answers Medium 3 possible answers Hard 4 Possible answers: ')
    if difficulty == 'Easy':
        print ('Biology questions first')
        for i in range (0,5):
            question = input(bio_questions[0][q1]).upper()
            if question == (bio_answers[a1]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')

            q1+=1
            a1+=1
     
        for x in range (0,5):
            question = input(cs_questions[0][q2]).upper()
            if question == (cs_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Bio & CS")
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
                
    elif difficulty == 'Medium':
        print ('Biology questions first')
        for i in range (0,5):
            question = input(bio_questions[1][q1]).upper()
            if question == (bio_answers[a1]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')

            q1+=1
            a1+=1
     
        for x in range (0,5):
            question = input(cs_questions[1][q2]).upper()
            if question == (cs_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Bio & CS")
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
                
    elif difficulty == 'Hard':
        print ('Biology questions first')
        for i in range (0,5):
            question = input(bio_questions[2][q1]).upper()
            if question == (bio_answers[a1]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')

            q1+=1
            a1+=1
     
        for x in range (0,5):
            question = input(cs_questions[2][q2]).upper()
            if question == (cs_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Bio & CS")        
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
            
def phy_cs(username, score):
    i = 0
    x = 0
    q1 = 0
    a1 = 0
    q2 = 0
    a2 = 0
    difficulty = input('What difficulty would you like to play on?. Easy 2 possible answers Medium 3 possible answers Hard 4 Possible answers: ')
    if difficulty == 'Easy':
        print ('Physics questions first')
        for i in range (0,5):
            question = input (phy_questions[0][q1])
            if question == (phy_answers[a1]):
                print ('correct')
                score = score+1
            else:
                print ('WRONG')
                
            q1+=1
            a1+=1
                
        for x in range (0,5):
            question = input(cs_questions[0][q2]).upper()
            if question == (cs_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Phy & CS")
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
                        
    elif difficulty == 'Medium':
        print ('Physics questions first')
        for i in range (0,5):
            question = input (phy_questions[1][q1])
            if question == (phy_answers[a1]):
                print ('correct')
                score = score+1
            else:
                print ('WRONG')
                
            q1+=1
            a1+=1
                
        for x in range (0,5):
            question = input(cs_questions[1][q2]).upper()
            if question == (cs_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Phy & CS")
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
            
    elif difficulty == 'Hard':
        print ('Physics questions first')
        for i in range (0,5):
            question = input (phy_questions[2][q1])
            if question == (phy_answers[a1]):
                print ('correct')
                score = score+1
            else:
                print ('WRONG')
                
            q1+=1
            a1+=1
                
        for x in range (0,5):
            question = input(cs_questions[2][q2]).upper()
            if question == (cs_answers[a2]):
                print('correct')
                score = score + 1
            else:
                print('WRONG')
            q2+=1
            a2+=1

        print ('You got',score,'out of 10')
        file1 = open ('NEA score.csv','a+')
        score = str(score)
        c_topic = ("Phy & CS")
        data = username+','+score+','+difficulty+','+c_topic
        file1.write (str(data))
        file1.write ('\n')
        file1.close()
        main()
                  
    else:
        print ('Invalid response please try again')
 
def teacher():
    myfile1 = open ('NEA score.csv','r')
    with open ('NEA score.csv') as File:
        reader = csv.reader(File)
        for row in reader:
          x = 0
          for x in range (0,1):
            print(' '.join(row))
        
while True:
  main()